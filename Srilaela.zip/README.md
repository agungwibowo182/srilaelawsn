
![enter image description here](https://i.ibb.co/ry6HN74/image.png)

# Kartu Ucapan Selamat Ulang Tahun
## Feature
 1. Fast Loading / Loading Cepat
 2. Responsive 
 3. Easy Edit / mudah di edit
 4. Skill Coding Standart (tidak terlu jago coding)
 
## Cara Menggunakan
1.  jalankan
git clone https://github.com/Cloud-Dark/pop-up-gift-card-happy-bhirtday
2. Replace File img.jpeg sesuai file yang anda butuhkan
3. Replace File music.mp3 Sesuai yang kalian inginkan
4. Edit Text in Html
5. Done
    ![enter image description here](https://i.ibb.co/zG0RX3g/image.png)
## Sepecial Thanks For
- Image From [Pixels](https://www.pexels.com/search/couple%20in%20love/)
- Music From [Youtube](https://www.youtube.com/watch?v=E5O6nXH9LeY)
- Source From [Codepen](https://codepen.io/search/pens?q=birthday%20card)
- And You
